def main():
    print("Hello from get-paper!")

if __name__ == "__main__":
    main()
