def main():
    print("Fetching research papers...!")

if __name__ == "__main__":
    main()
